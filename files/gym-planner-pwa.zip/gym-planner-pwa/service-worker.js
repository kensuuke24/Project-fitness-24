// Project Fitness XXIV — Service Worker
// Handles: offline app-shell caching, install lifecycle, and the
// evening check-in reminder notification.

const CACHE_NAME = 'pf24-cache-v1';
const APP_SHELL = [
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './icon-512-maskable.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Cache-first for the app shell, falling back to network, so the
// tracker still opens (and stays usable) with no connection.
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
          return res;
        })
        .catch(() => cached);
    })
  );
});

// Tapping the reminder notification focuses (or opens) the app.
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientsArr) => {
      const existing = clientsArr.find((c) => 'focus' in c);
      if (existing) return existing.focus();
      return self.clients.openWindow('./index.html');
    })
  );
});

// Best-effort background reminder. Periodic Background Sync only runs
// on installed PWAs on Chromium/Android (with the browser's engagement
// heuristics deciding if/when it actually fires) — it's not supported
// on iOS Safari. The in-app check on load/foreground is what covers
// everyone else; this is a bonus for the browsers that support it.
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'pf24-checkin-reminder') {
    event.waitUntil(maybeShowReminder());
  }
});

// Some browsers only expose one-off Background Sync; treat it the same way.
self.addEventListener('sync', (event) => {
  if (event.tag === 'pf24-checkin-reminder') {
    event.waitUntil(maybeShowReminder());
  }
});

async function maybeShowReminder() {
  await self.registration.showNotification('Project Fitness XXIV', {
    body: 'Huwag kalimutan ang check-in mo ngayong araw \u2014 tap para buksan.',
    icon: './icon-192.png',
    badge: './icon-192.png',
    tag: 'pf24-checkin',
    renotify: true
  });
}
